package lab2ques2;



import java.util.Scanner;

public class lab2ques2 {

	public static void main(String[] args) {
		
	
	}

}
