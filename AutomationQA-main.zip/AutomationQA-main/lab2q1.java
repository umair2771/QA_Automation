package lab2ques2;



import java.util.Scanner;

public class stringtokenizer {
	
	private String inputstr;
	
	public void data(String inputstr)
	{
		return inputstr;
		
		
	}
	
	
	public void counttoken()
	{
		
		int leng=0;
		leng=inputstr.length();
		
		for(int i=0;i<leng;i++)
		{
			
			
			
			
			
		}
		
		
		
		
		
	}
	
	
	
	

	public static void main(String[] args) {
		
		
            
      
	}

}
